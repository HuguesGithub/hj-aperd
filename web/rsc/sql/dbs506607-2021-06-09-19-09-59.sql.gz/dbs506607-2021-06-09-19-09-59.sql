-- Adminer 4.7.1 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';

DROP TABLE IF EXISTS `wp_14_aperd_administration`;
CREATE TABLE `wp_14_aperd_administration` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `labelPoste` varchar(64) NOT NULL,
  `nomTitulaire` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `wp_14_aperd_annee_scolaire`;
CREATE TABLE `wp_14_aperd_annee_scolaire` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `anneeScolaire` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `wp_14_aperd_bilan_matiere`;
CREATE TABLE `wp_14_aperd_bilan_matiere` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `compteRenduId` int(10) unsigned NOT NULL,
  `matiereId` tinyint(3) unsigned NOT NULL,
  `enseignantId` smallint(5) unsigned NOT NULL,
  `status` varchar(1) NOT NULL,
  `observations` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `compteRenduId` (`compteRenduId`),
  KEY `matiereId` (`matiereId`),
  KEY `enseignantId` (`enseignantId`),
  CONSTRAINT `wp_14_aperd_bilan_matiere_ibfk_1` FOREIGN KEY (`compteRenduId`) REFERENCES `wp_14_aperd_compte_rendu` (`id`) ON DELETE CASCADE,
  CONSTRAINT `wp_14_aperd_bilan_matiere_ibfk_2` FOREIGN KEY (`matiereId`) REFERENCES `wp_14_aperd_matiere` (`id`) ON DELETE CASCADE,
  CONSTRAINT `wp_14_aperd_bilan_matiere_ibfk_3` FOREIGN KEY (`enseignantId`) REFERENCES `wp_14_aperd_enseignant` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `wp_14_aperd_compo_division`;
CREATE TABLE `wp_14_aperd_compo_division` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `anneeScolaireId` tinyint(3) unsigned NOT NULL,
  `divisionId` tinyint(3) unsigned NOT NULL,
  `matiereId` tinyint(3) unsigned NOT NULL,
  `enseignantId` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `classeId` (`divisionId`),
  KEY `matiereId` (`matiereId`),
  KEY `enseignantId` (`enseignantId`),
  KEY `anneeScolaireId` (`anneeScolaireId`),
  CONSTRAINT `wp_14_aperd_compo_division_ibfk_1` FOREIGN KEY (`divisionId`) REFERENCES `wp_14_aperd_division` (`id`) ON DELETE CASCADE,
  CONSTRAINT `wp_14_aperd_compo_division_ibfk_2` FOREIGN KEY (`matiereId`) REFERENCES `wp_14_aperd_matiere` (`id`) ON DELETE CASCADE,
  CONSTRAINT `wp_14_aperd_compo_division_ibfk_3` FOREIGN KEY (`enseignantId`) REFERENCES `wp_14_aperd_enseignant` (`id`) ON DELETE CASCADE,
  CONSTRAINT `wp_14_aperd_compo_division_ibfk_4` FOREIGN KEY (`anneeScolaireId`) REFERENCES `wp_14_aperd_annee_scolaire` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `wp_14_aperd_compte_rendu`;
CREATE TABLE `wp_14_aperd_compte_rendu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `crKey` varchar(16) NOT NULL,
  `anneeScolaireId` tinyint(3) unsigned NOT NULL,
  `trimestre` tinyint(3) unsigned NOT NULL,
  `divisionId` tinyint(3) unsigned NOT NULL,
  `nbEleves` tinyint(3) unsigned NOT NULL,
  `dateConseil` varchar(10) NOT NULL,
  `administrationId` tinyint(3) unsigned NOT NULL,
  `enseignantId` smallint(5) unsigned NOT NULL,
  `parent1` varchar(64) NOT NULL,
  `parent2` varchar(64) DEFAULT NULL,
  `enfant1` varchar(64) NOT NULL,
  `enfant2` varchar(64) DEFAULT NULL,
  `bilanProfPrincipal` text NOT NULL,
  `bilanEleves` text NOT NULL,
  `bilanParents` text NOT NULL,
  `nbEncouragements` tinyint(3) unsigned NOT NULL,
  `nbCompliments` tinyint(3) unsigned NOT NULL,
  `nbFelicitations` tinyint(3) unsigned NOT NULL,
  `nbMgComportement` tinyint(3) unsigned NOT NULL,
  `nbMgTravail` tinyint(3) unsigned NOT NULL,
  `nbMgComportementTravail` tinyint(3) unsigned NOT NULL,
  `dateRedaction` varchar(10) NOT NULL,
  `auteurRedaction` varchar(64) NOT NULL,
  `mailContact` varchar(64) NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `anneeScolaireId` (`anneeScolaireId`),
  KEY `classeId` (`divisionId`),
  CONSTRAINT `wp_14_aperd_compte_rendu_ibfk_1` FOREIGN KEY (`anneeScolaireId`) REFERENCES `wp_14_aperd_annee_scolaire` (`id`) ON DELETE CASCADE,
  CONSTRAINT `wp_14_aperd_compte_rendu_ibfk_2` FOREIGN KEY (`divisionId`) REFERENCES `wp_14_aperd_division` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `wp_14_aperd_config_questionnaire`;
CREATE TABLE `wp_14_aperd_config_questionnaire` (
  `configKey` varchar(32) NOT NULL,
  `configValue` varchar(64) NOT NULL,
  UNIQUE KEY `configKey` (`configKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `wp_14_aperd_division`;
CREATE TABLE `wp_14_aperd_division` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `labelDivision` varchar(8) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `wp_14_aperd_eleve`;
CREATE TABLE `wp_14_aperd_eleve` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nomEleve` varchar(32) NOT NULL,
  `prenomEleve` varchar(32) NOT NULL,
  `divisionId` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `divisionId` (`divisionId`),
  CONSTRAINT `wp_14_aperd_eleve_ibfk_1` FOREIGN KEY (`divisionId`) REFERENCES `wp_14_aperd_division` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `wp_14_aperd_enseignant`;
CREATE TABLE `wp_14_aperd_enseignant` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `nomEnseignant` varchar(64) NOT NULL,
  `matiereId` tinyint(3) unsigned DEFAULT NULL,
  `status` tinyint(1) unsigned DEFAULT '1',
  `genre` varchar(4) DEFAULT NULL,
  `prenomEnseignant` varchar(64) DEFAULT NULL,
  `anneeScolaireId` tinyint(3) unsigned DEFAULT NULL,
  `divisionId` tinyint(3) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `wp_14_aperd_enseignant_matiere`;
CREATE TABLE `wp_14_aperd_enseignant_matiere` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `enseignantId` smallint(5) unsigned NOT NULL,
  `matiereId` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `enseignantId` (`enseignantId`),
  KEY `matiereId` (`matiereId`),
  CONSTRAINT `wp_14_aperd_enseignant_matiere_ibfk_1` FOREIGN KEY (`enseignantId`) REFERENCES `wp_14_aperd_enseignant` (`id`) ON DELETE CASCADE,
  CONSTRAINT `wp_14_aperd_enseignant_matiere_ibfk_2` FOREIGN KEY (`matiereId`) REFERENCES `wp_14_aperd_matiere` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `wp_14_aperd_matiere`;
CREATE TABLE `wp_14_aperd_matiere` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `labelMatiere` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `wp_14_aperd_prof_princ`;
CREATE TABLE `wp_14_aperd_prof_princ` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `anneeScolaireId` tinyint(3) unsigned DEFAULT NULL,
  `divisionId` tinyint(3) unsigned DEFAULT NULL,
  `enseignantId` smallint(5) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `anneeScolaireId` (`anneeScolaireId`),
  KEY `classeId` (`divisionId`),
  KEY `enseignantId` (`enseignantId`),
  CONSTRAINT `wp_14_aperd_prof_princ_ibfk_1` FOREIGN KEY (`anneeScolaireId`) REFERENCES `wp_14_aperd_annee_scolaire` (`id`) ON DELETE CASCADE,
  CONSTRAINT `wp_14_aperd_prof_princ_ibfk_2` FOREIGN KEY (`divisionId`) REFERENCES `wp_14_aperd_division` (`id`) ON DELETE CASCADE,
  CONSTRAINT `wp_14_aperd_prof_princ_ibfk_3` FOREIGN KEY (`enseignantId`) REFERENCES `wp_14_aperd_enseignant` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- 2021-06-09 17:09:59
